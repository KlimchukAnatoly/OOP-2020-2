#include "Ch.h"

int main() {
	ch game;
	game.go();
}